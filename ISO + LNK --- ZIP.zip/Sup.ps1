$serviceExists = $false

while (-not $serviceExists) {
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i sup.msi /qb" -Wait
    
    Start-Sleep -Seconds 10
    
    $serviceExists = Get-Service -Name "AteraAgent" -ErrorAction SilentlyContinue
    
    if ($serviceExists) {
        Write-Host "The AteraAgent service was found. The MSI package installation is complete."
    }
    else {
        Write-Host "The AteraAgent service was not found. Restarting the MSI package installation..."
    }
}